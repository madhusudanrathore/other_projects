package com.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;

@WebServlet("/upload")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter writer = response.getWriter();
		String appPath = request.getServletContext().getRealPath("");
		String realPath = appPath + "img/";
		writer.println(realPath);
		File fileDir = new File(realPath);

		if (!fileDir.exists()) {
			fileDir.mkdirs();
		} else {
			writer.print("dir is exist");
		}
        
		ServletFileUpload fileUpload = new ServletFileUpload(new DiskFileItemFactory());
		try {

			List<FileItem> fileItems = fileUpload.parseRequest(request);
		    for (FileItem fileItem : fileItems) {
				
		    	if(fileItem.isFormField()) {
		    	   writer.println(fileItem.getString());	
		    	}
		    	else {
		    		
		    	String tempName=fileItem.getName();
		    	String newFileName=String.valueOf(System.nanoTime());
				
		    	newFileName=newFileName+"."+FilenameUtils.getExtension(tempName); 
			    fileItem.write(new File(realPath+newFileName));
		        writer.println("file upload is ::");

		    	}
		    	}
		 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
